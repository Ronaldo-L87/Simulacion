# -*- coding: utf-8 -*-
"""
Created on Sun Feb 26 18:11:45 2023

@author: Ronaldo L
"""

# BIBLIOTECAS

import numpy as np
import scipy as sp
import plotly
import plotly.graph_objs as go
from scipy import integrate
import time

# -----------------------------------------------------------------------------
#                               ACEPTACION Y RECHAZO
# -----------------------------------------------------------------------------


def Normal(X, mu, sigma):
    return np.array((1/np.sqrt(2*np.pi*sigma)) * (np.exp(-0.5*(X-mu)**2/sigma)))

def Cauchy(X):
    return np.array(1/(np.pi*(1+X**2)))

def t(X):
    return (2/(np.sqrt(5*np.pi) * 1.32934)) * (1 + X**2/5)**(-3)

def Maximizar():
    def Cociente(X):
        #return -1*Normal(X, 0, 1)/Cauchy(X)
        #return -1*Normal(X, 0, 1)/t(X)
        return -1*Normal(X, 0, 1)/(0.4*Normal(X, -1, 1) + 0.6 * Normal(X, 1, 1))
    return sp.optimize.minimize_scalar(Cociente, bounds=(-1,1), method="Bounded")["fun"]

def Distribucion(X):
    x = np.arange(-20,X,0.001)
    #return integrate.cumtrapz(0.4*Normal(x, -1, 1) + 0.6*Normal(x, 1, 1), x)[-1]
    return integrate.cumtrapz(t(x),x)[-1]
    
    

# ---------------------------------------------------------------------------

C = -Maximizar()


# Transformada inversa para Cauchy
def Inversa_Cauchy(u):
    return np.array(np.tan(np.pi*(u-0.5)))


# Transformada inversa para T y mezcla de normales

def Inversa(u):
    def Error(X):
        return np.abs(Distribucion(X)-u)
    return sp.optimize.minimize_scalar(Error)["x"]


n = 10**3
X = np.array(0)

#  (u <= (Normal(y, 0, 1)/(C * (0.4*Normal(y, -1, 1) + 0.6*Normal(y, 1, 1)))))
# (u <= (Normal(y, 0, 1)) / (C * Cauchy(y)))
# (u <= (Normal(y, 0, 1)) / (C * t(y)))
for i in range(n):
    flag = 0
    while flag == 0:
        u = np.random.uniform(size=1)
        #y = Inversa_Cauchy(np.random.uniform())
        y = Inversa(np.random.uniform())
        if (u <= (Normal(y, 0, 1)/(C * (0.4*Normal(y, -1, 1) + 0.6*Normal(y, 1, 1))))):
            X = np.append(X, y)
            flag=1

X = X[-n:]    

# Graficar
density, bins = np.histogram(X, density=True)
trace1  = go.Histogram(
            xbins= dict(start = bins[0],
                       end= bins[-1],
                       size= min(np.diff(bins))+0.01
            ),
            x = X,
            histnorm= "probability density",
            name="Simulaciones"
        )
    
trace2 = go.Scatter(
            mode="lines",
            x = np.arange(min(X),max(X),0.005),
            y = Normal(np.arange(min(X),max(X),0.005), 0 ,1),
            name = "Teórica",
            line=dict(dash='dot')
        )
    
data = [trace1, trace2]
    
layout = go.Layout(
        title_text='Mezcla de normales',
        xaxis=dict(
            title="x"),
        yaxis=dict(
            title="f(x)") 
        ) 
fig = go.Figure(data=data, layout=layout)
    #nombre = 'C:/Users/Ronaldo L/Downloads/' + "figura " +  str(i+1) + "_Ej1.png" 
plotly.offline.plot(fig)


# -----------------------------------------------------------------------------
#                               COCIENTE DE UNIFORMES
# -----------------------------------------------------------------------------

def Normal(X, mu, sigma):
    return np.array((1/np.sqrt(2*np.pi*sigma)) * (np.exp(-0.5*(X-mu)**2/sigma)))

def Gamma(X, alpha, beta):
    if X >= 0:
        return (beta**(alpha)*X**(alpha-1)/(8.85534))*np.exp(-beta*X)
    else:
        return 0

def Maximizar():
    def Error(X):
        #return -1*np.sqrt(Normal(X, 0, 1))
        return -1*np.sqrt(Gamma(X, 4.3, 0.5))
    return sp.optimize.minimize_scalar(Error)["fun"]

def Max2():
    def Error(X):
            #return -1*X*np.sqrt(Normal(X, 0, 1))
            return -1*X*np.sqrt(Gamma(X, 4.3, 0.5))
    return sp.optimize.minimize_scalar(Error)["fun"]

a = 0
b = -Maximizar()
c = Max2()
d = -c

n = 10**3
X = np.array(0)
# x <= np.sqrt(Gamma(y/x, 4.3 , 0.5))
#(x <= np.sqrt(Normal(y/x, 0 , 1)))
for i in range(n):
    flag = 0
    while flag == 0:
        x = np.random.uniform(low = a, high= b)
        y = np.random.uniform(low = c, high= d)
        if (x <= np.sqrt(Gamma(y/x, 4.3 , 0.5))):
            X = np.append(X, y/x)
            flag=1

X = X[-n:]

# Graficar
density, bins = np.histogram(X, density=True)
y = []
for i in np.arange(min(X),max(X),0.005):
    y.append(Gamma(i, 4.3, 0.5))
trace1  = go.Histogram(
            xbins= dict(start = bins[0],
                       end= bins[-1],
                       size= min(np.diff(bins))+0.01
            ),
            x = X,
            histnorm= "probability density",
            name="Simulaciones"
        )
    
trace2 = go.Scatter(
            mode="lines",
            x = np.arange(min(X),max(X),0.005),
            y = y,
            name = "Teórica",
            line=dict(dash='dot')
        )
    
data = [trace1, trace2]
    
layout = go.Layout(
        title_text='Cociente de uniformes para Gamma(4.3, 0.5)',
        xaxis=dict(
            title="x"),
        yaxis=dict(
            title="f(x)") 
        ) 
fig = go.Figure(data=data, layout=layout)
    #nombre = 'C:/Users/Ronaldo L/Downloads/' + "figura " +  str(i+1) + "_Ej1.png" 
plotly.offline.plot(fig)


 
# -----------------------------------------------------------------------------
#                               BOX - MÜLLER
# -----------------------------------------------------------------------------


n=10**3
u1 = np.random.uniform(size=n)
u2 = np.random.uniform(size=n)

n1 = (-2*np.log(u1))**(1/2)*np.cos(2*np.pi*u2)
n2 = (-2*np.log(u1))**(1/2)*np.sin(2*np.pi*u2)


def seno(x):
    return x - x**3 / 6
    
def coseno(x):
    #return (1 - x**2 / 2)
    return 1 - x**2 /2 + x**4 / 24
    
# Ahora usando la serie de Taylor de segundo grado

m1 = (-2*np.log(u1))**(1/2)*coseno(2*np.pi*u2)
m2 = (2*np.pi*u2)*(-2*np.log(u1))**(1/2)


# Ahora usando la serie de Taylor de cuarto grado

m1 = (-2*np.log(u1))**(1/2)*coseno(2*np.pi*u2)
m3 = (-2*np.log(u1))**(1/2)*seno(2*np.pi*u2)



# -----------------------------------------------------------------------------
#                               MARSAGLIA
# -----------------------------------------------------------------------------

# Creando dos uniformes en caso de no cumplir R^2<=1
n = 10**3

inicio = time.time()
for j in range(100):
    n1 = []
    n2 = []
    for i in range(n):
        flag = 0
        while flag == 0:
            v1 = np.random.uniform(low=-1, high=1)
            v2 = np.random.uniform(low=-1, high=1)
            if (v1**2 + v2**2) <= 1:
                n1.append((-2*np.log(v1**2 + v2**2))**(1/2)*v2/((v1**2 + v2**2)**(1/2)))
                n2.append((-2*np.log(v1**2 + v2**2))**(1/2)*v1/((v1**2 + v2**2)**(1/2)))
                flag=1
fin = time.time()
print(fin - inicio)

#density, bins = np.histogram(n2, density=True)



# Creando solo una uniforme en caso de no cumple R^2<=1

inicio = time.time()
for j in range(100):
    n1 = []
    n2 = []
    for i in range(n):
        v1 = np.random.uniform(low=-1, high=1)
        v2 = np.random.uniform(low=-1, high=1)
        while (v1**2 + v2**2) > 1:
            v3 = v2
            v2 = np.random.uniform(low=-1, high=1)
            v1 = v3
        n1.append((-2*np.log(v1**2 + v2**2))**(1/2)*v2/((v1**2 + v2**2)**(1/2)))
        n2.append((-2*np.log(v1**2 + v2**2))**(1/2)*v1/((v1**2 + v2**2)**(1/2)))
fin = time.time()
print(fin - inicio)

# -----------------------------------------------------------------------------
#                               MEDIAS MUESTRALES
# -----------------------------------------------------------------------------



def Normal(X, mu, sigma):
    return np.array((1/np.sqrt(2*np.pi*sigma)) * (np.exp(-0.5*(X-mu)**2/sigma)))

def Gamma2(X, alpha, beta):
    return (beta**(alpha)*X**(alpha-1)/(362880))*np.exp(-beta*X)

def Dist(X):
    #"""
    if X > 0:
        x = np.arange(0,X,0.001)
        return integrate.cumtrapz(Gamma2(x, 10, 0.1),x)[-1]
    else:
        return 10**5
    #"""
    #x = np.arange(-20,X,0.001)
    #return integrate.cumtrapz(Normal(x, 0, 1), x)[-1]
    
    
def Inversa_Cauchy(u):
    return np.tan(np.pi*(u-0.5))

def Inversa(u):
    def Error(X):
        return np.abs(Dist(X)-u)
    return sp.optimize.minimize_scalar(Error)["x"]

n=10**3
u = np.random.uniform(size=n)
x = []
j = 0
for i in u:
    x.append(Inversa(i))  
    j +=1
    print(j)
    #x.append(Inversa_Cauchy(i))

#print(np.mean(x))
    
ns = np.arange(1,n+1)

trace1  = go.Scatter(
            mode = "lines",
            line=dict(dash='dot'),
            x = ns,
            y = 100*np.ones(len(x)),
            name = "100"
        )
    
trace2 = go.Scatter(
            mode="lines",
            x = ns,
            y = np.cumsum(x)/ns,
            name = "Media muestral"
            #line=dict(dash='dot')
        )
    
data = [trace1, trace2]
    
layout = go.Layout(
        title_text='Media muestral para Gamma(10, 0.1)',
        xaxis=dict(
            title="Tamaño de muestra"),
        yaxis=dict(
            title="Media muestral") 
        ) 
fig = go.Figure(data=data, layout=layout)
    #nombre = 'C:/Users/Ronaldo L/Downloads/' + "figura " +  str(i+1) + "_Ej1.png" 
plotly.offline.plot(fig)

# -----------------------------------------------------------------------------
#                               CADENA DE MARKOV
# -----------------------------------------------------------------------------

P = np.array([[0.7, 0.2, 0.1], [1/3, 1/3, 1/3], [0.1, 0.45, 0.45]])

x0 = 1


n = 10**5
X = np.array(x0)
for i in range(n):
    u = np.random.uniform()
    k = 0
    while (u > np.cumsum(P[x0])[k]):
        k += 1
    X = np.append(X, k)
    x0 = X[-1]
    
Estados = np.unique(X, return_counts=True)

probas = Estados[1] / (n+1)

P1 = P
for i in range(100):
    P = P@P1
    
# -----------------------------------------------------------------------------
#                               PROCESO POISSON
# -----------------------------------------------------------------------------

#Transformada Inversa para Poisson

def Poisson(lambda0):
    u = np.random.uniform()
    P0 = np.exp(-lambda0)
    k = 0
    suma = P0
    while u > suma:
        k+=1
        P0 = (lambda0/k)*P0
        suma += P0
    return k

lambda0 = 3*20

# Simulación de Proceso poisson

poi = Poisson(lambda0)
U = np.array(0)
u = np.sort(np.random.uniform(low = 0, high = 20, size = poi))

U = np.append(U, u)
U = np.append(U, 20)

est = np.arange(poi+1)

data = []
for i in range(len(U)-1):
    trace1 = go.Scatter(
                mode = "lines",
                x = np.arange(U[i], U[i+1], 10**(-5)),
                y = est[i]*np.ones(len(np.arange(U[i], U[i+1], 10**(-5)))),
                name = "u" + str(i)
            )
    data.append(trace1)

    
layout = go.Layout(
        title_text='Proceso Poisson',
        xaxis=dict(
            title="T"),
        yaxis=dict(
            title="Estado") 
        ) 
fig = go.Figure(data=data, layout=layout)
    #nombre = 'C:/Users/Ronaldo L/Downloads/' + "figura " +  str(i+1) + "_Ej1.png" 
plotly.offline.plot(fig)

# -----------------------------------------------------------------------------
#                               MOVIMIENTO BROWNIANO
# -----------------------------------------------------------------------------
def Normal(X, mu, sigma):
    return np.array((1/np.sqrt(2*np.pi*sigma)) * (np.exp(-0.5*(X-mu)**2/sigma)))

def Distribucion2(X):
    x = np.arange(-20,X,0.001)
    return integrate.cumtrapz(Normal(x, 0, 1), x)[-1]
    
def Inversa(u):
    def Error(X):
        return np.abs(Distribucion2(X)-u)
    return sp.optimize.minimize_scalar(Error)["x"]


t = 10**(-3)
T = np.arange(0, 1+t, t)
data=[]
j=0
for i in range(20):
    B = [0]
    
    for i in range(len(T)-1):
        B.append(B[i] + Inversa(np.random.uniform())*np.sqrt(t))
        
        
    trace1 = go.Scatter(
                mode = "lines",
                x = T,
                y = B,
                name = "MB 1"
            )
    data.append(trace1)
    j += 1
    print(j)

layout = go.Layout(
        title_text='Movimiento Browniano',
        xaxis=dict(
            title="T"),
        yaxis=dict(
            title="Estado") 
        ) 
fig = go.Figure(data=data, layout=layout)
    #nombre = 'C:/Users/Ronaldo L/Downloads/' + "figura " +  str(i+1) + "_Ej1.png" 
plotly.offline.plot(fig)

    





