# -*- coding: utf-8 -*-
"""
Created on Thu Mar 23 09:47:45 2023

@author: Ronaldo L
"""

from mpl_toolkits.mplot3d import Axes3D
import numpy as np
import scipy as sp
from scipy.stats import norm, gamma, multivariate_normal
import matplotlib.pyplot as plt
from matplotlib import cm
from scipy import integrate
import math
import itertools


# -----------------------------------------------------------------------------
#                               EJERCICIO 1
# -----------------------------------------------------------------------------

# Normal bivariada con corr = 0

n = 10**3

x = norm.rvs(size = n)
y = norm.rvs(size = n)
    
# ---------------------------
fig = plt.figure(figsize=(12,12))
ax = fig.add_subplot(projection='3d')
hist, xedges, yedges = np.histogram2d(x, y, bins=16, range=[[min(x), max(x)], [min(y), max(y)]], density=True)

# Construct arrays for the anchor positions of the 16 bars.
xpos, ypos = np.meshgrid(xedges[:-1], yedges[:-1], indexing="ij")
xpos = xpos.ravel()
ypos = ypos.ravel()
zpos = 0

# Construct arrays with the dimensions for the 16 bars.
dx = dy = 0.5 * np.ones_like(zpos)
dz = hist.ravel()

ax.bar3d(xpos, ypos, zpos, dx, dy, dz, zsort='average', color="turquoise")
plt.show()


# -------------------------
def scatter_hist(x, y, ax, ax_histx, ax_histy):
    ax_histx.tick_params(axis="x", labelbottom=False)
    ax_histy.tick_params(axis="y", labelleft=False)

    ax.scatter(x, y, c = "darkcyan")
    
    binwidth = 0.3
    xymax = max(np.max(np.abs(x)), np.max(np.abs(y)))
    lim = (int(xymax/binwidth) + 1) * binwidth
    
    w = np.arange(-4, 4, 0.1)
    pdf = norm.pdf(w)
    

    bins = np.arange(-lim, lim + binwidth, binwidth)
    ax_histx.hist(x, bins=bins, density=True, color = "cornflowerblue")
    ax_histx.plot(w, pdf, c ="red")
    ax_histy.hist(y, bins=bins, orientation='horizontal', density=True, color="cornflowerblue")
    ax_histy.plot(pdf,  w, "red")
    

fig = plt.figure(figsize=(10, 10))

gs = fig.add_gridspec(2, 2,  width_ratios=(4, 1), height_ratios=(1, 4),
                      left=0.1, right=0.9, bottom=0.1, top=0.9,
                      wspace=0.05, hspace=0.05)

ax = fig.add_subplot(gs[1, 0])
ax_histx = fig.add_subplot(gs[0, 0], sharex=ax)
ax_histy = fig.add_subplot(gs[1, 1], sharey=ax)
scatter_hist(x, y, ax, ax_histx, ax_histy)
    


# Normal bivariada con corr = 0.5

n = 10**3

z1 = norm.rvs(size = n)
z2 = norm.rvs(size = n)

mu_x = 1
mu_y = 1
sigma_x = 1
sigma_y = 1
p = 0.5

x = sigma_x*z1 + mu_x
y = sigma_y*(p*z1 + np.sqrt(1-p**2)* z2) + mu_y

X, Y = np.meshgrid(x,y)

# ---------
fig = plt.figure(figsize=(10,10))
ax = fig.add_subplot(projection='3d')
hist, xedges, yedges = np.histogram2d(x, y, bins=16, range=[[min(x), max(x)], [min(y), max(y)]], density=True)

# Construct arrays for the anchor positions of the 16 bars.
xpos, ypos = np.meshgrid(xedges[:-1], yedges[:-1], indexing="ij")
xpos = xpos.ravel()
ypos = ypos.ravel()
zpos = 0

# Construct arrays with the dimensions for the 16 bars.
dx = dy = 0.5 * np.ones_like(zpos)
dz = hist.ravel()

ax.bar3d(xpos, ypos, zpos, dx, dy, dz, zsort='average', color="turquoise")
plt.show()


# ---------
def scatter_hist(x, y, ax, ax_histx, ax_histy):
    ax_histx.tick_params(axis="x", labelbottom=False)
    ax_histy.tick_params(axis="y", labelleft=False)

    ax.scatter(x, y, c = "darkcyan")
    
    binwidth = 0.3
    xymax = max(np.max(np.abs(x)), np.max(np.abs(y)))
    lim = (int(xymax/binwidth) + 1) * binwidth
    
    w = np.arange(-3, 5, 0.1)
    pdf = norm.pdf(w, loc=1, scale= 1)
    

    bins = np.arange(-lim, lim + binwidth, binwidth)
    ax_histx.hist(x, bins=bins, density=True, color = "cornflowerblue")
    ax_histx.plot(w, pdf, c ="red")
    ax_histy.hist(y, bins=bins, orientation='horizontal', density=True, color="cornflowerblue")
    ax_histy.plot(pdf,  w, "red")
    

fig = plt.figure(figsize=(10, 10))

gs = fig.add_gridspec(2, 2,  width_ratios=(4, 1), height_ratios=(1, 4),
                      left=0.1, right=0.9, bottom=0.1, top=0.9,
                      wspace=0.05, hspace=0.05)

ax = fig.add_subplot(gs[1, 0])
ax_histx = fig.add_subplot(gs[0, 0], sharex=ax)
ax_histy = fig.add_subplot(gs[1, 1], sharey=ax)
scatter_hist(x, y, ax, ax_histx, ax_histy)

# V.a. bivariada con marginales normales mu = 0 y var = 1
def Cu(v):
    return (4*np.exp(2/(u-1))) / ((u-1)**2 * (np.exp(2/(u-1)) + np.exp(2/(v-1))) * np.log(np.exp(2/(u-1)) + np.exp(2/(v-1)))**2)


def Inversa(t):
    def Error(X):
        return np.abs(Cu(X) - t)
    return sp.optimize.minimize_scalar(Error, method="bounded", bounds=(0,1))["x"]

n1 = []
n2 = []

for i in range(n):
    u = np.random.uniform()
    t = np.random.uniform()
    v = Inversa(t)
    n1.append(norm.ppf(u))
    n2.append(norm.ppf(v))

x = n1
y = n2
# ---------
fig = plt.figure(figsize=(10,10))
ax = fig.add_subplot(projection='3d')
hist, xedges, yedges = np.histogram2d(x, y, bins=16, range=[[min(x), max(x)], [min(y), max(y)]], density=True)

# Construct arrays for the anchor positions of the 16 bars.
xpos, ypos = np.meshgrid(xedges[:-1], yedges[:-1], indexing="ij")
xpos = xpos.ravel()
ypos = ypos.ravel()
zpos = 0

# Construct arrays with the dimensions for the 16 bars.
dx = dy = 0.5 * np.ones_like(zpos)
dz = hist.ravel()

ax.bar3d(xpos, ypos, zpos, dx, dy, dz, zsort='average', color="turquoise")
plt.show()


# ---------
def scatter_hist(x, y, ax, ax_histx, ax_histy):
    ax_histx.tick_params(axis="x", labelbottom=False)
    ax_histy.tick_params(axis="y", labelleft=False)

    ax.scatter(x, y, c = "darkcyan")
    
    binwidth = 0.3
    xymax = max(np.max(np.abs(x)), np.max(np.abs(y)))
    lim = (int(xymax/binwidth) + 1) * binwidth
    
    w = np.arange(-4, 4, 0.1)
    pdf = norm.pdf(w, loc=0, scale= 1)
    

    bins = np.arange(-lim, lim + binwidth, binwidth)
    ax_histx.hist(x, bins=bins, density=True, color = "cornflowerblue")
    ax_histx.plot(w, pdf, c ="red")
    ax_histy.hist(y, bins=bins, orientation='horizontal', density=True, color="cornflowerblue")
    ax_histy.plot(pdf,  w, "red")
    

fig = plt.figure(figsize=(10, 10))

gs = fig.add_gridspec(2, 2,  width_ratios=(4, 1), height_ratios=(1, 4),
                      left=0.1, right=0.9, bottom=0.1, top=0.9,
                      wspace=0.05, hspace=0.05)

ax = fig.add_subplot(gs[1, 0])
ax_histx = fig.add_subplot(gs[0, 0], sharex=ax)
ax_histy = fig.add_subplot(gs[1, 1], sharey=ax)
scatter_hist(x, y, ax, ax_histx, ax_histy)
    


# -----------------------------------------------------------------------------
#                               EJERCICIO 2
# -----------------------------------------------------------------------------

normal = []
dgamma = []
U = []
V = []
for i in range(n):
    u = np.random.uniform()
    t = np.random.uniform()
    v = Inversa(t)
    normal.append(norm.ppf(u))
    dgamma.append(gamma.ppf(v, a=3, scale=1/1.5))
    U.append(u)
    V.append(v)

plt.scatter(U, V)
plt.title("Simulación de C(u,v)")
plt.xlabel("U")
plt.ylabel("V")

x = normal
y = dgamma
def scatter_hist(x, y, ax, ax_histx, ax_histy):
    ax_histx.tick_params(axis="x", labelbottom=False)
    ax_histy.tick_params(axis="y", labelleft=False)

    ax.scatter(x, y, c = "darkcyan")
    
    binwidth = 0.3
    xymax = max(np.max(np.abs(x)), np.max(np.abs(y)))
    lim = (int(xymax/binwidth) + 1) * binwidth
    
    w = np.arange(-4, 4, 0.1)
    pdf = norm.pdf(w, loc=0, scale= 1)
    
    m = np.arange(0, 5, 0.01)
    pdf2 = gamma.pdf(m, a=3, scale=1/1.5)

    bins = np.arange(-lim, lim + binwidth, binwidth)
    ax_histx.hist(x, bins=bins, density=True, color = "cornflowerblue")
    ax_histx.plot(w, pdf, c ="red")
    ax_histy.hist(y, bins=bins, orientation='horizontal', density=True, color="cornflowerblue")
    ax_histy.plot(pdf2,  m, "red")
    

fig = plt.figure(figsize=(10, 10))

gs = fig.add_gridspec(2, 2,  width_ratios=(4, 1), height_ratios=(1, 4),
                      left=0.1, right=0.9, bottom=0.1, top=0.9,
                      wspace=0.05, hspace=0.05)

ax = fig.add_subplot(gs[1, 0])
ax_histx = fig.add_subplot(gs[0, 0], sharex=ax)
ax_histy = fig.add_subplot(gs[1, 1], sharey=ax)
scatter_hist(x, y, ax, ax_histx, ax_histy)



# -----------------------------------------------------------------------------
#                               EJERCICIO 3
# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
#                               EJERCICIO 4
# -----------------------------------------------------------------------------

def Inversa_Laplace(u, k, lamb, m):
    if u < k**2/(1+k**2):
        return m+(k/lamb) * np.log(u*(1+k**2)/k**2)
    else:
        return m - np.log((1-u)*(1+k**2))/(lamb*k)

n = 10**3 + 1
x = []
u = np.random.uniform(size=n)
for i in u:
    x.append(Inversa_Laplace(i, 1.5, 2, 0))
    
mediana = np.sort(x)
mediana[501]

media = np.sum(x)/n
media

# -----------------------------------------------------------------------------
#                               EJERCICIO 5
# -----------------------------------------------------------------------------

def X_barra(X):
    X_bar = []
    for i in range(X.shape[1]):
        X_bar.append(np.mean(X[:,i]))
    return np.array(X_bar)

# Para m=2
m=2
mean = np.zeros(m)
var = np.identity(m)

n = 10*4
X = multivariate_normal.rvs(size=n, mean=mean, cov = var)

X_bar = X_barra(X)

media_X_bar = np.mean(X_bar)
var_X_bar = np.var(X_bar) * m
media_X_bar
var_X_bar

mu_tilde = (1 - (m-2)*(1/n)/ np.sum(X_bar**2)) * X_bar
media_mu_tilde = np.mean(mu_tilde) 
var_mu_tilde = np.var(X_bar) * m/(m-1)
media_mu_tilde
var_mu_tilde

L1 = (mu_tilde - np.zeros(m))**2
media_L1 = np.mean(L1)
var_L1 = np.var(L1) * m/(m-1)
media_L1
var_L1

L2 = (X_bar - np.zeros(m))**2
media_L2 = np.mean(L1)
var_L2 = np.var(L2) * m/(m-1)
media_L2
var_L2
    
L3 = (X_bar - mu_tilde)**2
media_L3 = np.mean(L3)
var_L3 = np.var(L3) * m/(m-1)
media_L3
var_L3

# -----------------------------------------------------------------------------
#                               EJERCICIO 6
# -----------------------------------------------------------------------------


# Van der Corput

# Convertir el número decimal a una diferente base, pero ahorrando el paso de invertir los residuos
def decimal_a_base(num, base):
    m = []
    while math.trunc(num/base) != 0:
        m.append(num % base)
        num = math.trunc(num/base)
    m.append(num % base)
    return m

# Pasamos del número "invertido" a decimal
def base_a_decimal(num, base):
    suma = 0
    for i in range(1, len(num)+1):
        suma+= num[i-1] * base**(-i)
    return suma

# Usando base 10 para ambos ejes
n = 100
seq = []
for i in range(n):
    num = decimal_a_base(i, 10)
    seq.append(base_a_decimal(num, 10))

XY = [seq, seq]

prod = []

for element in itertools.product(*XY):
    prod.append(list(element))
    
prod = np.array(prod)

plt.scatter(prod[:,0], prod[:,1])
plt.title("Van der Corput para base 10")
plt.xlabel("X")
plt.ylabel("Y")



# Usando base 7 y base 11

n = 100
seq7 = []
seq11 = []

for i in range(n):
    num = decimal_a_base(i, 7)
    seq7.append(base_a_decimal(num, 7))
    num = decimal_a_base(i, 11)
    seq11.append(base_a_decimal(num, 11))

XY = [seq7, seq11]

prod = []

for element in itertools.product(*XY):
    prod.append(list(element))
    
prod = np.array(prod)

plt.scatter(prod[:,0], prod[:,1])
plt.title("Van der Corput para base 7 y 11")
plt.xlabel("X")
plt.ylabel("Y")

# Hammerseley

# Rehusando seq7 tal que U*_i = ( (i-1)/N , seq7) 

unif = []

for i in range(n):
    unif.append(i/n)

XY = [unif, seq7]

prod = []

for element in itertools.product(*XY):
    prod.append(list(element))
    
prod = np.array(prod)

plt.scatter(prod[:,0], prod[:,1])
plt.title("Hammersley para base 7 y 11")
plt.xlabel("X")
plt.ylabel("Y")









