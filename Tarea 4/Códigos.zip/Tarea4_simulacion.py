# -*- coding: utf-8 -*-
"""
Created on Thu Apr 20 10:46:15 2023

@author: Ronaldo L
"""

import numpy as np
from scipy.stats import expon, gamma, multivariate_normal, bernoulli, lognorm, norm
import math
import matplotlib.pyplot as plt
from statsmodels.graphics.tsaplots import plot_acf

# -----------------------------------------------------------------------------
#                               EJERCICIO 2
# -----------------------------------------------------------------------------


data = [ 0.3292034, 0.4251084, 0.7001423, 1.7175335, 0.4127446, 0.7386927, 0.3311653, 0.7333610, 1.3709668, 0.3422751]

r1 = np.sum(data)
r2 = 1
for i in range(len(data)):
    r2 *= data[i]

def f(alpha, beta, n):
    if ((alpha > 1 ) & (alpha <4) & (beta > 0)):
        return beta**(n*alpha)*r2**(alpha-1)*np.exp(-beta*(1+r1))/(math.gamma(alpha)**n) 
    return 0

def p(x, y):
    return np.min([1, f(y[0], y[1], len(data))/f(x[0], x[1], len(data))])

# Caso 1 
x_t = np.array([np.random.uniform(1,4),expon.rvs(1)])

#Caso 2
#x_t = np.array([1.0001,10])

x_l = np.array(x_t)

m = 10**3
for i in range(m-1):
    y_t = x_t + multivariate_normal.rvs(mean=[0,0], cov=[[1,0], [0,1]])
    #print(p(x_t, y_t))
    if bernoulli.rvs(p(x_t, y_t)) == 1:
        x_t = y_t
    
    x_l = np.vstack((x_l, x_t))

#Pasos de la cadena
plt.plot(x_l[:,0], x_l[:,1])
plt.xlabel("α")
plt.ylabel("β")

# Logaritmo de la densidad
dens = []
for i in range(m):
    dens.append(np.log(f(x_l[i][0], x_l[i][1], len(data))))
    #dens.append(f(x_l[i][0], x_l[i][1], len(data)))

#Burn-in
m = 10**3
plt.plot(np.arange(m), dens[0:m])
plt.xlabel("Iteraciones")
plt.ylabel("log(f(x))")
plt.axvline(x=250, color="red")

#Lag de alpha
plot_acf(x_l[:,0], lags=75)
plt.xlabel("LAG")
plt.ylabel("ACF")

l = 150
m = 75

muestra = np.array(x_l[l-1])

i = 1
k = l + m
while(k <= len(x_l)):
    muestra = np.vstack((muestra, x_l[k-1]))
    i += 1
    k = l + i*m

# Curvas de nivel
x = np.arange(1, 4, 0.01)
y = np.arange(0, 10, 0.01)
X, Y = np.meshgrid(x, y)
Z = []
for i in range(X.shape[0]):
    for j in range(X.shape[1]):
        Z.append(f(X[i][j], Y[i][j], len(data)))
Z = np.array(Z).reshape(X.shape[0], X.shape[1])

plt.contour(X,Y,Z, 10) 
plt.scatter(muestra[:,0], muestra[:,1])
plt.xlabel("α")
plt.ylabel("β")
plt.title("Curvas de nivel")



# -----------------------------------------------------------------------------
#                         EJERCICIO 3 INCISO A
# -----------------------------------------------------------------------------

def mezcla(x):
    return 0.5 * multivariate_normal.pdf(x = x, mean= [0, 0], cov= [[1, 0.6], [0.6, 2]]) + 0.5* multivariate_normal.pdf(x = x, mean= [5,5], cov=[[4, -0.9], [-0.9, 0.5]])

def p2(x,y):
    return np.min([1, mezcla(y) / mezcla(x)])

x_l = x_t = np.array([np.random.uniform(low=-2, high=8), np.random.uniform(low=-2, high=8)])

m = 10**5

for i in range(m-1):
    y_t = x_t + multivariate_normal.rvs(mean=[0,0], cov= [[0.1,0],[0,0.1]])
    if bernoulli.rvs(p2(x_t, y_t)) == 1:
        x_t = y_t
    
    x_l = np.vstack((x_l, x_t))


m = 10**3
dens2 = []
for i in range(m):
    dens2.append(np.log(mezcla(x_l[i])))
    

#Burn-in
m = 10**3
plt.plot(np.arange(m), dens2[0:m])
plt.xlabel("Iteraciones")
plt.ylabel("log(f(x))")
plt.axvline(x=200, color="red")


#Lag 
plot_acf(x_l[:,0], lags=7000)
plt.xlabel("LAG")
plt.ylabel("ACF")


#Pasos de la cadena
plt.plot(x_l[:,0], x_l[:,1])
plt.xlabel("α")
plt.ylabel("β")


l = 190
m = 6800

muestra = np.array(x_l[l-1])

i = 1
k = l + m
while(k <= len(x_l)):
    muestra = np.vstack((muestra, x_l[k-1]))
    i += 1
    k = l + i*m

# Curvas de nivel
x = np.arange(-4, 12, 0.1)
y = np.arange(-4, 8, 0.1)
X, Y = np.meshgrid(x, y)
Z = []
for i in range(X.shape[0]):
    for j in range(X.shape[1]):
        Z.append(mezcla([X[i][j], Y[i][j]]))
Z = np.array(Z).reshape(X.shape[0], X.shape[1])

plt.contour(X,Y,Z, 10) 
plt.scatter(muestra[:,0], muestra[:,1])
plt.xlabel("α")
plt.ylabel("β")
plt.title("Curvas de nivel")




# -----------------------------------------------------------------------------
#                         EJERCICIO 3 INCISO B
# -----------------------------------------------------------------------------


x_l = x_t = np.array([np.random.uniform(low=-2, high=8), np.random.uniform(low=-2, high=8)])

m = 10**4

for i in range(m-1):
    y_t = x_t + multivariate_normal.rvs(mean=[0,0], cov= [[5,0],[0,5]])
    if bernoulli.rvs(p2(x_t, y_t)) == 1:
        x_t = y_t
    
    x_l = np.vstack((x_l, x_t))

dens2 = []
for i in range(m):
    dens2.append(np.log(mezcla(x_l[i])))
    
#Burn-in
m = 10**3
plt.plot(np.arange(m), dens2[0:m])
plt.xlabel("Iteraciones")
plt.ylabel("log(f(x))")
plt.axvline(x=100, color="red")

#Lag
plot_acf(x_l[:,0], lags=170)
plt.xlabel("LAG")
plt.ylabel("ACF")

plt.plot(x_l[:,0], x_l[:,1])

l=100
m = 165


muestra = np.array(x_l[l-1])

i = 1
k = l + m
while(k <= len(x_l)):
    muestra = np.vstack((muestra, x_l[k-1]))
    i += 1
    k = l + i*m


# Curvas de nivel
x = np.arange(-4, 12, 0.1)
y = np.arange(-6, 8, 0.1)
X, Y = np.meshgrid(x, y)
Z = []
for i in range(X.shape[0]):
    for j in range(X.shape[1]):
        Z.append(mezcla([X[i][j], Y[i][j]]))
Z = np.array(Z).reshape(X.shape[0], X.shape[1])

plt.contour(X,Y,Z, 10) 
plt.scatter(muestra[:,0], muestra[:,1])
plt.xlabel("α")
plt.ylabel("β")
plt.title("Curvas de nivel")



# -----------------------------------------------------------------------------
#                               EJERCICIO 4
# -----------------------------------------------------------------------------

alpha = 2.7
beta = 2.8
alpha_techo = math.ceil(alpha)

x_l = x_t = np.array(gamma.rvs(a=alpha_techo, scale=1/beta))

def ro4(x, y):
    return np.min([1,  y**(alpha- alpha_techo) * x**(alpha_techo - alpha)])

m = 10**5

N = 0
for i in range(m-1):
    y_t = gamma.rvs(a=alpha_techo, scale=1/beta)
    if bernoulli.rvs(ro4(x_t, y_t)) == 1:
        x_t = y_t
        N +=1
        
    x_l = np.append(x_l, x_t)

dens4 = np.log(gamma.pdf(x= x_l,a = alpha, scale= 1/beta))

#log
m = 10**3
plt.plot(np.arange(m), dens4[0:m])
plt.xlabel("Iteraciones")
plt.ylabel("log(f(x))")
plt.axvline(x=100, color="red")

#LAG
plot_acf(x_l, lags=4)
plt.xlabel("LAG")
plt.ylabel("ACF")

#Densidad
l = 100
m = 4

muestra = np.array(x_l[l-1])
k = l + m
i= 1
while(k <= len(x_l)):
    muestra = np.append(muestra, x_l[k-1])
    i += 1
    k = l + i*m

plt.plot(np.arange(0, max(muestra), 0.01), gamma.pdf(np.arange(0, max(muestra), 0.01), a=alpha, scale=1/beta), color="red")
plt.hist(muestra, density=True, bins=20, color="dodgerblue")
plt.xlabel("X")
plt.ylabel("f(x)")
plt.title("Función de densidad de Gamma(2.7, 2.8)")
plt.legend(["Función de densidad", "Histograma de las muestras"])

# -----------------------------------------------------------------------------
#                               EJERCICIO 5
# -----------------------------------------------------------------------------

mu = 0.5
var = 1

def ro5(x, y):
    return np.min([1, (y/x)**alpha * np.exp(-beta*(y - x)) * np.exp(-(1/(2*var)) * ((np.log(x) - mu)**2 - (np.log(y)-mu)**2))])

x_l = x_t = np.array(np.random.lognormal(0.5, 1))

m = 10**5
N= 0
for i in range(m-1):
    y_t = np.random.lognormal(0.5, 1)
    if bernoulli.rvs(ro5(x_t, y_t)) == 1:
        x_t = y_t
        N += 1    
    x_l = np.append(x_l, x_t)

dens5 = np.log(gamma.pdf(x= x_l,a = alpha, scale= 1/beta))


#log
m = 10**3
plt.plot(np.arange(m), dens5[0:m])
plt.xlabel("Iteraciones")
plt.ylabel("log(f(x))")
plt.axvline(x=50, color="red")

#LAG
plot_acf(x_l, lags=8)
plt.xlabel("LAG")
plt.ylabel("ACF")

#Densidad
l = 50
m = 8

muestra = np.array(x_l[l-1])
k = l + m
i= 1
while(k <= len(x_l)):
    muestra = np.append(muestra, x_l[k-1])
    i += 1
    k = l + i*m

plt.plot(np.arange(0, max(muestra), 0.01), gamma.pdf(np.arange(0, max(muestra), 0.01), a=alpha, scale=1/beta), color="red")
plt.hist(muestra, density=True, bins=20, color="dodgerblue")
plt.xlabel("X")
plt.ylabel("f(x)")
plt.title("Función de densidad de Gamma(2.7, 2.8)")
plt.legend(["Función de densidad", "Histograma de las muestras"])

def lognorm(w):
    u = []
    for i in w:
        u.append( (1/(i*var*np.sqrt(2*np.pi)) * np.exp(- (np.log(i) - mu)**2 / (2*var)) ))
    return u
    


w = np.arange(0, 10, 0.01)

gam = gamma.pdf(w, a=2.7, scale=1/beta) 
ear = gamma.pdf(w, a=3, scale=1/beta)
logn = lognorm(w[1:len(w)])

plt.plot(w, gam)
plt.plot(w, ear)
plt.plot(w[1:len(w)], logn)
plt.legend(["Gamma", "Erlang", "Lognormal"])



# -----------------------------------------------------------------------------
#                               EJERCICIO 7
# -----------------------------------------------------------------------------



























