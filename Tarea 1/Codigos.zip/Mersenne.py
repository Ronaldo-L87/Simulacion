# -*- coding: utf-8 -*-
"""
Created on Fri Feb 17 20:37:38 2023

@author: Ronaldo L
"""
import numpy as np
import plotly
import plotly.graph_objs as go

def semilla(w, n):
    sec = np.arange(0, n, 1)
    x = [bin(a)[2:].zfill(w) for a in sec]
    x1 = []
    for i in x:
        x1.append(Enteros(i))
    return np.array(x1)
    
def Enteros(x):
    return np.array([int(k) for k in x])

def Decimales(z): 
    string = "".join([str(a) for a in z])
    string = "0b" + string
    return eval(string)

def Lower(X,r):
    return X[len(X)-r:]

def Upper(X,r):
    return X[:len(X)-r]

def Barra(X,Y,r):
    return np.append(Upper(X,r),Lower(Y,r))

def DesplazaDerecha(X,r):
    return np.hstack((np.zeros(r),X[:-r])).astype(int)

def DesplazaIzquierda(X, r):
    return np.hstack((X[r:],np.zeros(r))).astype(int)

# Función principal
def Mersenne(n):
    # Paramétros 
    a = 0x9908B0DF
    a = bin(a)[2:]
    a = Enteros(a)
    b = 0x9D2C5680
    b = bin(b)[2:]
    b = Enteros(b)
    c = 0xEFC60000
    c = bin(c)[2:]
    c = Enteros(c)
    u = 11
    s = 7
    t = 15
    l = 18
    params = np.array([32, 624, 397, 31])
    
    x = semilla(params[0], params[1])
    # Generar n números "aleatorios"
    z = []
    for k in range(n):
        x1 = Barra(x[k], x[k+1], params[-1])
        if x1[-1] == 0:
            x1 = DesplazaDerecha(x1, 1)
        else:
            x1 = np.bitwise_xor(DesplazaDerecha(x1, 1), a)
        x2 = np.bitwise_xor(x[k+params[-2]],x1)
          
        y = np.bitwise_xor(x2, DesplazaDerecha(x2, u))
        y = np.bitwise_xor(y, DesplazaIzquierda(y, s) & b)
        y = np.bitwise_xor(y, DesplazaIzquierda(y, t) & c)
        z.append(np.bitwise_xor(y, DesplazaDerecha(y, l)))
        x = np.vstack((x, z[k]))
        
    numeros = [Decimales(a) for a in z]
    return np.array(numeros)
    
n = 10**4

X = Mersenne(n)
len(np.unique(X))


plotly.offline.plot({"data": [go.Scatter(mode = "markers",x=np.arange(1,n+1), y=X,
                                         marker=dict(color="red", size=12),
                                         line=dict(dash='dot', color="black"))],
                     "layout": go.Layout(title="Mersenne Twister",
                                         xaxis=dict(title="i"), 
                                         yaxis=dict(title="X_i"))},        
                     image='png', image_filename='fig4.6')

density, bins = np.histogram(X)

plotly.offline.plot({"data": [go.Histogram(x=X, xbins= dict(start = bins[0],
                                                                end= bins[-1],
                                                                size= min(np.diff(bins))+0.01))],
                         "layout": go.Layout(title="Mersenne Twister",
                                             xaxis=dict(title="i"),
                                             yaxis=dict(title="X_i"))},
                         image='png', image_filename='fig4.9')




