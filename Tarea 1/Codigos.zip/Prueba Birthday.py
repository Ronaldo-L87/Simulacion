# -*- coding: utf-8 -*-
"""
Created on Wed Feb  1 18:09:15 2023

@author: Ronaldo L
"""

import numpy as np
from scipy.stats import poisson
import plotly
from plotly import graph_objs as go
import plotly.graph_objs as go
import scipy.stats as stats

def genera_Y():
    X = np.round(np.random.uniform(size=2**12, low=0, high=1)*2**32)
    X = np.sort(X)

    diferencia = np.sort(np.array(X[1:len(X)] - X[0:len(X)-1]))
    
    unicos, r = np.unique(diferencia, return_counts=True)
    repetidos = unicos[r>1]
    
    repeticiones=0
    for k in repetidos:
        reps = np.sum(diferencia == k)
        if reps > 1:
            repeticiones += reps-1
    return repeticiones    

Y = []
for i in range(0,5000):
    Y.append(genera_Y())

x = np.unique(Y)

observado = []
for i in x:
    observado.append(np.sum(i == Y))

proba = poisson.pmf(x[0:len(x)-1], mu=4)
proba = np.append(proba, 1-sum(proba))

f_esperado = sum(observado) * proba
sum(f_esperado)
    
# --------- Gráficas

trace1  = go.Histogram(
        bingroup=1,
        x = Y,
        name = "Y"
    )

trace2 = go.Scatter(
        x = x,
        y = f_esperado,
        name="Poisson"
    )

data = [trace1, trace2]

layout = go.Layout(
    title_text='Birthday Spacing Test para random uniform',
    xaxis=dict(
        title="x"),
    yaxis=dict(
        title="P(X=x)") 
    ) 
fig = go.Figure(data=data, layout=layout)
plotly.offline.plot(fig)


# ------------ Prueba X^2 de bondad de ajuste

estadistico, p_valor = stats.chisquare(f_obs= observado, f_exp=f_esperado)

print(f"Estadístico:     {estadistico:.5g}")
print(f"p-valor:            {p_valor:.5g}")

estadistico = 0
for i in range(len(observado)):
    estadistico = estadistico + ((observado[i] - f_esperado[i])**2 / f_esperado[i])
estadistico
