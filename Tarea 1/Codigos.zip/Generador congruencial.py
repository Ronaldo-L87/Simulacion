# -*- coding: utf-8 -*-
"""
Created on Sat Jan 28 17:07:39 2023

@author: Ronaldo L
"""

import numpy as np 
import plotly
import plotly.graph_objs as go

## Generador congruencial lineal

def Grafica(x,y,i):
    plotly.offline.plot({"data": [go.Scatter(mode = "markers+text",x=x, y=y,
                                             marker=dict(color="red", size=12))],
                         "layout": go.Layout(title="Generador Congruencial",
                                             xaxis=dict(title="X_i"), 
                                             yaxis=dict(title="X_i+1"))},        
                         image='png', image_filename='fig1.'+ str(i))

def generador_congruencial(a,b,c,x0, n):
    x = np.array(x0)
    for i in range(n): # m+1 para ver si tiene rango completo
        x0 = (a*x0+b)%m
        x = np.append(x,x0)
    return x

# Caso 1
a = 5
b = 0
m = 11
x0 = 1

X = generador_congruencial(a,b,m,x0, m)
X
periodos = np.where(X == x0)
periodos # No tiene periodo completo, se empieza a repetir cada 5 números.
Grafica(X[:len(X)-1], X[1:],1)


# Caso 2
a = 5
b = 0 
m = 1000

Y = generador_congruencial(a,b,m,x0, m)
Y[0:10]
periodos = np.where(Y == x0)
periodos # No tiene periodo completo, se cicla en 125 y 625 al quinto número 
Grafica(Y[:len(Y)-1], Y[1:],2)

#Caso 3
a= 781
b = 387
m = 1000

Z = generador_congruencial(a,b,m,x0, m)
periodos = np.where(Z==x0)
periodos # Tiene periodo completo m (m=1000)
Grafica(Z[:len(Z)-1], Z[1:],3)

# ----------------------------------------------------------------- #
# ----------------------- Otros 2 casos --------------------------- #
# ----------------------------------------------------------------- #

# Primer caso
a = 2**34 + 1
b = 1
m = 2**35

X = generador_congruencial(a, b, m, x0, 100000)
periodo_X = np.where(X==x0)
periodo_X
Grafica(X[:len(X)-1], X[1:],4)

# Segundo caso

a = 2**18 + 1

Y = generador_congruencial(a, b, m, x0, m)
periodo_Y = np.where(Y==x0)
periodo_Y
Grafica(Y[:len(Y)-1], Y[1:], 7)

for i in range(2, 388):
    if (387 % i) == 0:
        print("No es primo")
        print(i)


































