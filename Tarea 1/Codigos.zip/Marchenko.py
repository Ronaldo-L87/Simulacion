# -*- coding: utf-8 -*-
"""
Created on Thu Feb 16 14:05:36 2023

@author: Ronaldo L
"""

from scipy import integrate
import scipy as sp
import numpy as np
from scipy.optimize import Bounds



def densidad(var, lam, X, lambda1, lambda2):
    fx = (1/(2*np.pi*var))*np.sqrt((lambda1 - X)*(X-lambda2))/(lam*X) 
    return fx

def Distribucion(X, lambda1, lambda2, lam):
    if lam <= 1:
        if (X >= lambda2) & (X <= lambda1):
            x = np.arange(lambda2,X,0.0001)
            return integrate.cumtrapz(densidad(var, lam, x, lambda1, lambda2),x)[-1]
        else:
            return 10**5
    else:
        if (X > lambda2) & (X < lambda1):
            x = np.arange(lambda2,X,0.0001)
            return ((1-1/lam) + integrate.cumtrapz(densidad(var, lam, x, lambda1, lambda2),x)[-1])
        else:
            return 10**5

def Inversa(a,lam):
    if lam <= 1:
        def Error(X):
            return np.abs(Distribucion(X, lambda1, lambda2, lam)-a)    
        return sp.optimize.minimize_scalar(Error, bounds = dom, tol=10**(-3))["x"]
    else:
        if a < (1-1/lam):
            return 0
        else:
            def Error(X):
                return np.abs(Distribucion(X, lambda1, lambda2, lam)-a)    
            return sp.optimize.minimize_scalar(Error, bracket=(lambda2+0.01, lambda1-0.01), bounds=dom, tol=10**(-3))["x"]
            
var = 1
lam = 5
lambda1 = var*(1 + np.sqrt(lam))**2
lambda2 = var*(1 - np.sqrt(lam))**2

dom = Bounds(lambda2, lambda1)
u = np.random.uniform(low=0, high=1, size=10000)
X = []
for i in u:
    X.append(Inversa(i, lam))
    
plotly.offline.plot({"data": [go.Scatter(mode = "markers",x=X, y=u,
                                         marker=dict(color="red", size=12),
                                         line=dict(dash='dot', color="black"))],
                     "layout": go.Layout(title="Transformada Inversa lambda= 5",
                                         xaxis=dict(title="X"), 
                                         yaxis=dict(title="F(X)"))},        
                     image='png', image_filename='fig8.3')
    




