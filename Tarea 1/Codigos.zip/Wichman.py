# -*- coding: utf-8 -*-
"""
Created on Sun Feb 19 14:33:55 2023

@author: Ronaldo L
"""

import numpy as np
import plotly
import plotly.graph_objs as go

def Wichman_Hill(x0, y0, z0, n):
    U = [((x0/30269) + (y0/30307) + (z0/30323)) % 1]
    for i in range(1, n):
        x0 = x0*171 % 30269
        y0 = y0*172 % 30307
        z0 = z0*170 % 30323
        U.append(((x0/30269) + (y0/30307) + (z0/30323)) % 1)
    return np.array(U)

n= 10**2
X = Wichman_Hill(5,5,5,n)

plotly.offline.plot({"data": [go.Scatter(mode = "markers+lines",x=np.arange(1,n+1), y=X,
                                         marker=dict(color="red", size=12),
                                         line=dict(dash='dot', color="black"))],
                     "layout": go.Layout(title="Generador Wichman-Hill",
                                         xaxis=dict(title="i"), 
                                         yaxis=dict(title="X_i"))},        
                     image='png', image_filename='fig3.1')