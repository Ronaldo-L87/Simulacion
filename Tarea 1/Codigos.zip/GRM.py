# -*- coding: utf-8 -*-
"""
Created on Sun Feb  5 01:38:52 2023

@author: Ronaldo L
"""

import numpy as np
import plotly
import plotly.graph_objs as go


def GRM(X, k, n):
    for t in range(0,n):
        X = np.append(X, (X[-1] + X[k+t-1] + 1)%2) # (X[-1] + X[55980+t] + 1)%2   Polinomio: X^42643801 + X^55981 + 1
    return X


t= 42643801 
X = np.arange(t)
k = 55981

x= GRM(X, k, 10**3)[t:]

plotly.offline.plot({"data": [go.Scatter(mode = "markers+lines",x=np.arange(1,101), y=x,
                                         marker=dict(color="red", size=12),
                                         line=dict(dash='dot', color="black"))],
                     "layout": go.Layout(title="Generador Recursivo Múltiple",
                                         xaxis=dict(title="i"), 
                                         yaxis=dict(title="X_i"))},        
                     image='png', image_filename='fig5.1')


