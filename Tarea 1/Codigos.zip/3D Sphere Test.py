# -*- coding: utf-8 -*-
"""
Created on Sun Feb  5 00:58:09 2023

@author: Ronaldo L
"""

import numpy as np
from scipy.stats import expon
import plotly
from plotly import graph_objs as go
import plotly.graph_objs as go
import matplotlib.pyplot as plt
from scipy.spatial.distance import cdist
import scipy.stats as stats


def genera_Y():
    x1 = np.random.uniform(high = 1000, low = 0, size =3)
    x2 = np.random.uniform(high = 1000, low = 0, size =3)
    X = np.vstack((x1,x2))
    for i in range(4000-2):
        x1 = np.random.uniform(high=1000, low=0, size=3)
        X = np.vstack((X,x1))
    
    min_dist = []
    for i in range(len(X)):
        y = np.delete(X, i, axis=0)
        min_dist.append(np.min(cdist([X[i]], y)))
    
    min_dist = np.min(min_dist)**3
    
    return min_dist

Y = []
for i in range(100):
    Y.append(genera_Y())

density, bins = np.histogram(Y, density=True)

observado = expon.pdf(bins, scale=30)

probas = density * np.diff(bins)

esp = []
esp.append(expon.cdf(bins[1], scale=30))
for i in range(2, len(bins)):
    esp.append(expon.cdf(bins[i], scale=30) - expon.cdf(bins[i-1], scale=30))
esp.append(1 - expon.cdf(bins[-1], scale=30))
esp = 100 * np.array(esp)

obs = []
Y = np.array(Y)
for i in range(1, len(bins)):
    obs.append(np.sum(Y < bins[i]) - np.sum(Y < bins[i-1]))
obs.append(np.sum(Y >= bins[-1]))

# ---------------------------- Gráficas
trace1  = go.Histogram(
        xbins= dict(start = bins[0],
                   end= bins[-1],
                   size= min(np.diff(bins))+0.01
        ),
        x = Y,
        name = "r^3",
        histnorm = "probability density"
    )

trace2 = go.Scatter(
        x = bins,
        y = observado,
        name="exponential"
    )

data = [trace1, trace2]

layout = go.Layout(
    title_text='3D Sphere test para random uniform',
    xaxis=dict(
        title="x"),
    yaxis=dict(
        title="P(X=x)") 
    ) 
fig = go.Figure(data=data, layout=layout)
plotly.offline.plot(fig)
# ----------------------------- Prueba ji cuadrada de bondad de ajuste

estadistico, p_valor = stats.chisquare(f_obs= obs, f_exp=esp)

stats.ks_2samp(Y, )

print(f"Estadístico:     {estadistico:.5g}")
print(f"p-valor:            {p_valor:.5g}")

estadistico = 0
for i in range(len(observado)):
    estadistico = estadistico + ((obs[i] - esp[i])**2 / esp[i])
estadistico

# ---------------------------- Prueba Kolmogorov Smirnov
esperado = expon.rvs(size = len(Y), scale=30)
stats.ks_2samp(Y, esperado)

 