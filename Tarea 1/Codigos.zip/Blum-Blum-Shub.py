# -*- coding: utf-8 -*-
"""
Created on Sat Jan 28 21:25:26 2023

@author: Ronaldo L
"""

import numpy as np 
import plotly
import plotly.graph_objs as go

def BBS(x0, m, n):
    x = [x0]
    for i in range(1, n):
        x.append(x[i-1]**2 % m)
    return x

p = 1267650600228229401496703981519
q = 1267650600228229401496704318359

for k in range(2, 10000):
    X = BBS(k, p*q, 10**3)
    X = np.unique(X)
    if len(X) != 10**3:
        print(k)
        break
    print(k, "=", len(X))
    
n = 10**4
X = BBS(10, p*q, n)

plotly.offline.plot({"data": [go.Scatter(mode = "markers",x=np.arange(1,n+1), y=X,
                                         marker=dict(color="red", size=12),
                                         line=dict(dash='dot', color="black"))],
                     "layout": go.Layout(title="Blum-Blum-Shub",
                                         xaxis=dict(title="i"), 
                                         yaxis=dict(title="X_i"))},        
                     image='png', image_filename='fig2.2')